## Noted Base

This code repository was created for the [AWS for Front-End Engineers (ft. S3, Cloudfront & Route 53) Course](https://frontendmasters.com/courses/aws-frontend-react/) for Frontend Masters.
