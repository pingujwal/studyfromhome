import { combineReducers } from 'redux';
import notes from './notes';

export default combineReducers({
  notes,
});
