	SELECT * FROM courses
	WHERE owner = 'bholt'
	AND name = 'Complete Intro to React, v47' OR 'a'='a';