## [1.0.137](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.136...v1.0.137) (2020-04-04)


### Bug Fixes

* **deps:** update dependency sequelize to v5.21.6 ([3c34783](https://github.com/mike-works/web-security-fundamentals.git/commit/3c34783))

## [1.0.136](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.135...v1.0.136) (2020-03-25)


### Bug Fixes

* **deps:** update dependency helmet to v3.22.0 ([46d79f8](https://github.com/mike-works/web-security-fundamentals.git/commit/46d79f8))

## [1.0.135](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.134...v1.0.135) (2020-03-24)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.10.0 ([98fda35](https://github.com/mike-works/web-security-fundamentals.git/commit/98fda35))

## [1.0.134](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.133...v1.0.134) (2020-03-20)


### Bug Fixes

* **deps:** update dependency morgan to v1.10.0 ([f9f8cd4](https://github.com/mike-works/web-security-fundamentals.git/commit/f9f8cd4))

## [1.0.133](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.132...v1.0.133) (2020-03-15)


### Bug Fixes

* **deps:** update dependency cookie-parser to v1.4.5 ([ebe32f5](https://github.com/mike-works/web-security-fundamentals.git/commit/ebe32f5))

## [1.0.132](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.131...v1.0.132) (2020-02-25)


### Bug Fixes

* **deps:** update dependency helmet to v3.21.3 ([cd1c237](https://github.com/mike-works/web-security-fundamentals.git/commit/cd1c237))

## [1.0.131](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.130...v1.0.131) (2020-02-23)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.9.5 ([c81178f](https://github.com/mike-works/web-security-fundamentals.git/commit/c81178f))

## [1.0.130](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.129...v1.0.130) (2020-02-20)


### Bug Fixes

* **deps:** update dependency sequelize to v5.21.5 ([d1506d7](https://github.com/mike-works/web-security-fundamentals.git/commit/d1506d7))

## [1.0.129](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.128...v1.0.129) (2020-02-07)


### Bug Fixes

* **deps:** update dependency sequelize to v5.21.4 ([dfd5099](https://github.com/mike-works/web-security-fundamentals.git/commit/dfd5099))

## [1.0.128](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.127...v1.0.128) (2020-02-05)


### Bug Fixes

* **deps:** update dependency bcrypt to v3.0.8 ([8637600](https://github.com/mike-works/web-security-fundamentals.git/commit/8637600))

## [1.0.127](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.126...v1.0.127) (2020-01-24)


### Bug Fixes

* **deps:** update dependency cookie-session to v2.0.0-rc.1 ([5ccbe99](https://github.com/mike-works/web-security-fundamentals.git/commit/5ccbe99))

## [1.0.126](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.125...v1.0.126) (2020-01-19)


### Bug Fixes

* **deps:** update dependency csurf to v1.11.0 ([22ba27d](https://github.com/mike-works/web-security-fundamentals.git/commit/22ba27d))

## [1.0.125](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.124...v1.0.125) (2019-12-13)


### Bug Fixes

* **deps:** update dependency sequelize to v5.21.3 ([386d244](https://github.com/mike-works/web-security-fundamentals.git/commit/386d244))

## [1.0.124](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.123...v1.0.124) (2019-12-05)


### Bug Fixes

* **deps:** update dependency sqlite3 to v4.1.1 ([c665119](https://github.com/mike-works/web-security-fundamentals.git/commit/c665119))

## [1.0.123](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.122...v1.0.123) (2019-11-19)


### Bug Fixes

* **deps:** update dependency ejs to v2.7.4 ([d02dbde](https://github.com/mike-works/web-security-fundamentals.git/commit/d02dbde))

## [1.0.122](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.121...v1.0.122) (2019-11-19)


### Bug Fixes

* **deps:** update dependency ejs to v2.7.3 ([ab7be5f](https://github.com/mike-works/web-security-fundamentals.git/commit/ab7be5f))

## [1.0.121](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.120...v1.0.121) (2019-11-18)


### Bug Fixes

* **deps:** update dependency bcrypt to v3.0.7 ([268599d](https://github.com/mike-works/web-security-fundamentals.git/commit/268599d))

## [1.0.120](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.119...v1.0.120) (2019-11-13)


### Bug Fixes

* **deps:** update dependency ejs to v2.7.2 ([b8fffa7](https://github.com/mike-works/web-security-fundamentals.git/commit/b8fffa7))

## [1.0.119](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.118...v1.0.119) (2019-11-02)


### Bug Fixes

* **deps:** update dependency sqlite3 to v4.1.0 ([1e5da1f](https://github.com/mike-works/web-security-fundamentals.git/commit/1e5da1f))

## [1.0.118](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.117...v1.0.118) (2019-10-29)


### Bug Fixes

* **deps:** update dependency sequelize to v5.21.2 ([c5806ff](https://github.com/mike-works/web-security-fundamentals.git/commit/c5806ff))

## [1.0.117](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.116...v1.0.117) (2019-10-22)


### Bug Fixes

* **deps:** update dependency helmet to v3.21.2 ([14e5974](https://github.com/mike-works/web-security-fundamentals.git/commit/14e5974))

## [1.0.116](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.115...v1.0.116) (2019-10-21)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.9.4 ([44e24b3](https://github.com/mike-works/web-security-fundamentals.git/commit/44e24b3))

## [1.0.115](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.114...v1.0.115) (2019-10-19)


### Bug Fixes

* **deps:** update dependency sequelize to v5.21.1 ([e7fe915](https://github.com/mike-works/web-security-fundamentals.git/commit/e7fe915))

## [1.0.114](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.113...v1.0.114) (2019-10-18)


### Bug Fixes

* **deps:** update dependency sequelize to v5.21.0 ([d1847d2](https://github.com/mike-works/web-security-fundamentals.git/commit/d1847d2))

## [1.0.113](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.112...v1.0.113) (2019-10-18)


### Bug Fixes

* **deps:** update dependency sequelize to v5.20.0 ([3979060](https://github.com/mike-works/web-security-fundamentals.git/commit/3979060))

## [1.0.112](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.111...v1.0.112) (2019-10-17)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.8 ([be41791](https://github.com/mike-works/web-security-fundamentals.git/commit/be41791))

## [1.0.111](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.110...v1.0.111) (2019-10-16)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.7 ([5695536](https://github.com/mike-works/web-security-fundamentals.git/commit/5695536))

## [1.0.110](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.109...v1.0.110) (2019-10-16)


### Bug Fixes

* **deps:** update dependency nodemon to v1.19.4 ([4d55e9a](https://github.com/mike-works/web-security-fundamentals.git/commit/4d55e9a))

## [1.0.109](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.108...v1.0.109) (2019-10-11)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.6 ([940e9e5](https://github.com/mike-works/web-security-fundamentals.git/commit/940e9e5))

## [1.0.108](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.107...v1.0.108) (2019-10-11)


### Bug Fixes

* **deps:** update dependency commander to v2.20.3 ([626d6c0](https://github.com/mike-works/web-security-fundamentals.git/commit/626d6c0))

## [1.0.107](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.106...v1.0.107) (2019-10-11)


### Bug Fixes

* **deps:** update dependency express-session to v1.17.0 ([102b776](https://github.com/mike-works/web-security-fundamentals.git/commit/102b776))

## [1.0.106](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.105...v1.0.106) (2019-10-09)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.5 ([a8cc089](https://github.com/mike-works/web-security-fundamentals.git/commit/a8cc089))

## [1.0.105](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.104...v1.0.105) (2019-10-07)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.4 ([f1dd2f8](https://github.com/mike-works/web-security-fundamentals.git/commit/f1dd2f8))

## [1.0.104](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.103...v1.0.104) (2019-10-05)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.3 ([5761c44](https://github.com/mike-works/web-security-fundamentals.git/commit/5761c44))

## [1.0.103](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.102...v1.0.103) (2019-10-01)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.2 ([20b3dee](https://github.com/mike-works/web-security-fundamentals.git/commit/20b3dee))

## [1.0.102](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.101...v1.0.102) (2019-10-01)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.9.3 ([9a94dda](https://github.com/mike-works/web-security-fundamentals.git/commit/9a94dda))

## [1.0.101](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.100...v1.0.101) (2019-09-29)


### Bug Fixes

* **deps:** update dependency nodemon to v1.19.3 ([7ff9d8f](https://github.com/mike-works/web-security-fundamentals.git/commit/7ff9d8f))

## [1.0.100](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.99...v1.0.100) (2019-09-28)


### Bug Fixes

* **deps:** update dependency commander to v2.20.1 ([afe76c7](https://github.com/mike-works/web-security-fundamentals.git/commit/afe76c7))

## [1.0.99](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.98...v1.0.99) (2019-09-27)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.1 ([bd509f2](https://github.com/mike-works/web-security-fundamentals.git/commit/bd509f2))

## [1.0.98](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.97...v1.0.98) (2019-09-20)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.9.2 ([5b51215](https://github.com/mike-works/web-security-fundamentals.git/commit/5b51215))

## [1.0.97](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.96...v1.0.97) (2019-09-20)


### Bug Fixes

* **deps:** update dependency helmet to v3.21.1 ([31dad36](https://github.com/mike-works/web-security-fundamentals.git/commit/31dad36))

## [1.0.96](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.95...v1.0.96) (2019-09-19)


### Bug Fixes

* **deps:** update dependency sequelize to v5.19.0 ([04258f8](https://github.com/mike-works/web-security-fundamentals.git/commit/04258f8))

## [1.0.95](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.94...v1.0.95) (2019-09-08)


### Bug Fixes

* **deps:** update dependency sequelize to v5.18.4 ([df7a29b](https://github.com/mike-works/web-security-fundamentals.git/commit/df7a29b))

## [1.0.94](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.93...v1.0.94) (2019-09-08)


### Bug Fixes

* **deps:** update dependency sequelize to v5.18.3 ([f9ab8a7](https://github.com/mike-works/web-security-fundamentals.git/commit/f9ab8a7))

## [1.0.93](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.92...v1.0.93) (2019-09-07)


### Bug Fixes

* **deps:** update dependency sequelize to v5.18.2 ([3fc99e3](https://github.com/mike-works/web-security-fundamentals.git/commit/3fc99e3))

## [1.0.92](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.91...v1.0.92) (2019-09-04)


### Bug Fixes

* **deps:** update dependency helmet to v3.21.0 ([b7ae7e1](https://github.com/mike-works/web-security-fundamentals.git/commit/b7ae7e1))

## [1.0.91](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.90...v1.0.91) (2019-09-04)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.9.1 ([7d38e96](https://github.com/mike-works/web-security-fundamentals.git/commit/7d38e96))

## [1.0.90](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.89...v1.0.90) (2019-09-03)


### Bug Fixes

* **deps:** update dependency nodemon to v1.19.2 ([2f35f26](https://github.com/mike-works/web-security-fundamentals.git/commit/2f35f26))

## [1.0.89](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.88...v1.0.89) (2019-09-03)


### Bug Fixes

* **deps:** update dependency sequelize to v5.18.1 ([bed32db](https://github.com/mike-works/web-security-fundamentals.git/commit/bed32db))

## [1.0.88](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.87...v1.0.88) (2019-09-02)


### Bug Fixes

* **deps:** update dependency ejs to v2.7.1 ([39afc1c](https://github.com/mike-works/web-security-fundamentals.git/commit/39afc1c))

## [1.0.87](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.86...v1.0.87) (2019-08-31)


### Bug Fixes

* **deps:** update dependency sequelize to v5.18.0 ([64c7733](https://github.com/mike-works/web-security-fundamentals.git/commit/64c7733))

## [1.0.86](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.85...v1.0.86) (2019-08-30)


### Bug Fixes

* **deps:** update dependency sequelize to v5.17.2 ([b58c0ee](https://github.com/mike-works/web-security-fundamentals.git/commit/b58c0ee))

## [1.0.85](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.84...v1.0.85) (2019-08-29)


### Bug Fixes

* **deps:** update dependency sequelize to v5.17.1 ([e275b79](https://github.com/mike-works/web-security-fundamentals.git/commit/e275b79))

## [1.0.84](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.83...v1.0.84) (2019-08-28)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.9.0 ([365974f](https://github.com/mike-works/web-security-fundamentals.git/commit/365974f))

## [1.0.83](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.82...v1.0.83) (2019-08-28)


### Bug Fixes

* **deps:** update dependency helmet to v3.20.1 ([e7b9ae8](https://github.com/mike-works/web-security-fundamentals.git/commit/e7b9ae8))

## [1.0.82](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.81...v1.0.82) (2019-08-28)


### Bug Fixes

* **deps:** update dependency sequelize to v5.17.0 ([5f8da55](https://github.com/mike-works/web-security-fundamentals.git/commit/5f8da55))

## [1.0.81](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.80...v1.0.81) (2019-08-22)


### Bug Fixes

* **deps:** update dependency sequelize to v5.16.0 ([9221f14](https://github.com/mike-works/web-security-fundamentals.git/commit/9221f14))

## [1.0.80](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.79...v1.0.80) (2019-08-21)


### Bug Fixes

* **deps:** update dependency sequelize to v5.15.2 ([021664c](https://github.com/mike-works/web-security-fundamentals.git/commit/021664c))

## [1.0.79](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.78...v1.0.79) (2019-08-18)


### Bug Fixes

* **deps:** update dependency sequelize to v5.15.1 ([e843caa](https://github.com/mike-works/web-security-fundamentals.git/commit/e843caa))

## [1.0.78](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.77...v1.0.78) (2019-08-14)


### Bug Fixes

* **deps:** update dependency sequelize to v5.15.0 ([e90df37](https://github.com/mike-works/web-security-fundamentals.git/commit/e90df37))

## [1.0.77](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.76...v1.0.77) (2019-08-13)


### Bug Fixes

* **deps:** update dependency sequelize to v5.14.0 ([5f9c53c](https://github.com/mike-works/web-security-fundamentals.git/commit/5f9c53c))

## [1.0.76](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.75...v1.0.76) (2019-08-11)


### Bug Fixes

* **deps:** update dependency sequelize to v5.13.1 ([a39ef78](https://github.com/mike-works/web-security-fundamentals.git/commit/a39ef78))

## [1.0.75](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.74...v1.0.75) (2019-08-09)


### Bug Fixes

* **deps:** update dependency sequelize to v5.13.0 ([acf36ad](https://github.com/mike-works/web-security-fundamentals.git/commit/acf36ad))

## [1.0.74](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.73...v1.0.74) (2019-08-04)


### Bug Fixes

* **deps:** update dependency sequelize to v5.12.3 ([9b9ea39](https://github.com/mike-works/web-security-fundamentals.git/commit/9b9ea39))

## [1.0.73](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.72...v1.0.73) (2019-07-31)


### Bug Fixes

* **deps:** update dependency sequelize to v5.12.2 ([fd69caa](https://github.com/mike-works/web-security-fundamentals.git/commit/fd69caa))

## [1.0.72](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.71...v1.0.72) (2019-07-30)


### Bug Fixes

* **deps:** update dependency sequelize to v5.12.1 ([7ebfa9a](https://github.com/mike-works/web-security-fundamentals.git/commit/7ebfa9a))

## [1.0.71](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.70...v1.0.71) (2019-07-30)


### Bug Fixes

* **deps:** update dependency sequelize to v5.12.0 ([33ed0f0](https://github.com/mike-works/web-security-fundamentals.git/commit/33ed0f0))

## [1.0.70](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.69...v1.0.70) (2019-07-27)


### Bug Fixes

* **deps:** update dependency sequelize to v5.11.0 ([f8b5af7](https://github.com/mike-works/web-security-fundamentals.git/commit/f8b5af7))

## [1.0.69](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.68...v1.0.69) (2019-07-25)


### Bug Fixes

* **deps:** update dependency sequelize to v5.10.3 ([df0ce2b](https://github.com/mike-works/web-security-fundamentals.git/commit/df0ce2b))

## [1.0.68](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.67...v1.0.68) (2019-07-24)


### Bug Fixes

* **deps:** update dependency helmet to v3.20.0 ([740f491](https://github.com/mike-works/web-security-fundamentals.git/commit/740f491))

## [1.0.67](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.66...v1.0.67) (2019-07-24)


### Bug Fixes

* **deps:** update dependency helmet-csp to v2.8.0 ([0c67fb7](https://github.com/mike-works/web-security-fundamentals.git/commit/0c67fb7))

## [1.0.66](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.65...v1.0.66) (2019-07-23)


### Bug Fixes

* **deps:** update dependency sequelize to v5.10.2 ([937cce0](https://github.com/mike-works/web-security-fundamentals.git/commit/937cce0))

## [1.0.65](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.64...v1.0.65) (2019-07-19)


### Bug Fixes

* **deps:** update dependency lodash to v4.17.15 ([7140f5b](https://github.com/mike-works/web-security-fundamentals.git/commit/7140f5b))

## [1.0.64](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.63...v1.0.64) (2019-07-17)


### Bug Fixes

* **deps:** update dependency helmet to v3.19.0 ([faaee38](https://github.com/mike-works/web-security-fundamentals.git/commit/faaee38))

## [1.0.63](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.62...v1.0.63) (2019-07-14)


### Bug Fixes

* **deps:** update dependency sequelize to v5.10.1 ([40dce28](https://github.com/mike-works/web-security-fundamentals.git/commit/40dce28))

## [1.0.62](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.61...v1.0.62) (2019-07-11)


### Bug Fixes

* **deps:** update dependency sequelize to v5.10.0 ([bf530b9](https://github.com/mike-works/web-security-fundamentals.git/commit/bf530b9))

## [1.0.61](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.60...v1.0.61) (2019-07-11)


### Bug Fixes

* **deps:** update dependency sequelize to v5.9.5 ([ef98642](https://github.com/mike-works/web-security-fundamentals.git/commit/ef98642))

## [1.0.60](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.59...v1.0.60) (2019-07-10)


### Bug Fixes

* **deps:** update dependency lodash to v4.17.14 ([07e26c3](https://github.com/mike-works/web-security-fundamentals.git/commit/07e26c3))

## [1.0.59](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.58...v1.0.59) (2019-07-10)


### Bug Fixes

* **deps:** update dependency lodash to v4.17.13 ([08765fc](https://github.com/mike-works/web-security-fundamentals.git/commit/08765fc))

## [1.0.58](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.57...v1.0.58) (2019-07-06)


### Bug Fixes

* **deps:** update dependency sequelize to v5.9.4 ([9066422](https://github.com/mike-works/web-security-fundamentals.git/commit/9066422))

## [1.0.57](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.56...v1.0.57) (2019-07-05)


### Bug Fixes

* **deps:** update dependency sequelize to v5.9.3 ([27a51ca](https://github.com/mike-works/web-security-fundamentals.git/commit/27a51ca))

## [1.0.56](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.55...v1.0.56) (2019-07-02)


### Bug Fixes

* **deps:** update dependency sequelize to v5.9.2 ([d553f1a](https://github.com/mike-works/web-security-fundamentals.git/commit/d553f1a))

## [1.0.55](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.54...v1.0.55) (2019-07-02)


### Bug Fixes

* **deps:** update dependency sequelize to v5.9.1 ([d02717f](https://github.com/mike-works/web-security-fundamentals.git/commit/d02717f))

## [1.0.54](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.53...v1.0.54) (2019-06-28)


### Bug Fixes

* **deps:** update dependency sequelize to v5.9.0 ([ace7b5a](https://github.com/mike-works/web-security-fundamentals.git/commit/ace7b5a))

## [1.0.53](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.52...v1.0.53) (2019-06-22)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.12 ([9177ae7](https://github.com/mike-works/web-security-fundamentals.git/commit/9177ae7))

## [1.0.52](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.51...v1.0.52) (2019-06-21)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.11 ([b267b66](https://github.com/mike-works/web-security-fundamentals.git/commit/b267b66))

## [1.0.51](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.50...v1.0.51) (2019-06-17)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.10 ([e9ed2a0](https://github.com/mike-works/web-security-fundamentals.git/commit/e9ed2a0))

## [1.0.50](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.49...v1.0.50) (2019-06-15)


### Bug Fixes

* **deps:** update dependency ejs to v2.6.2 ([0744f4d](https://github.com/mike-works/web-security-fundamentals.git/commit/0744f4d))

## [1.0.49](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.48...v1.0.49) (2019-06-13)


### Bug Fixes

* **deps:** update dependency sqlite3 to v4.0.9 ([5841cd2](https://github.com/mike-works/web-security-fundamentals.git/commit/5841cd2))

## [1.0.48](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.47...v1.0.48) (2019-06-12)


### Bug Fixes

* **deps:** update dependency express-session to v1.16.2 ([cfbbfe5](https://github.com/mike-works/web-security-fundamentals.git/commit/cfbbfe5))
* **deps:** update dependency express-session to v1.16.2 ([#139](https://github.com/mike-works/web-security-fundamentals.git/issues/139)) ([f9a284b](https://github.com/mike-works/web-security-fundamentals.git/commit/f9a284b))

## [1.0.47](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.46...v1.0.47) (2019-06-11)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.9 ([963d6f4](https://github.com/mike-works/web-security-fundamentals.git/commit/963d6f4))
* **deps:** update dependency sequelize to v5.8.9 ([#138](https://github.com/mike-works/web-security-fundamentals.git/issues/138)) ([f81a58f](https://github.com/mike-works/web-security-fundamentals.git/commit/f81a58f))

## [1.0.46](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.45...v1.0.46) (2019-06-10)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.8 ([e7d00e8](https://github.com/mike-works/web-security-fundamentals.git/commit/e7d00e8))

## [1.0.45](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.44...v1.0.45) (2019-05-29)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.7 ([0405045](https://github.com/mike-works/web-security-fundamentals.git/commit/0405045))

## [1.0.44](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.43...v1.0.44) (2019-05-26)


### Bug Fixes

* **deps:** update dependency express to v4.17.1 ([1340e87](https://github.com/mike-works/web-security-fundamentals.git/commit/1340e87))

## [1.0.43](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.42...v1.0.43) (2019-05-25)


### Bug Fixes

* **deps:** update dependency nodemon to v1.19.1 ([214b5fd](https://github.com/mike-works/web-security-fundamentals.git/commit/214b5fd))

## [1.0.42](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.41...v1.0.42) (2019-05-17)


### Bug Fixes

* **deps:** update dependency express to v4.17.0 ([c836522](https://github.com/mike-works/web-security-fundamentals.git/commit/c836522))

## [1.0.41](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.40...v1.0.41) (2019-05-12)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.6 ([06b32f0](https://github.com/mike-works/web-security-fundamentals.git/commit/06b32f0))

## [1.0.40](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.39...v1.0.40) (2019-05-11)


### Bug Fixes

* **deps:** update dependency sqlite3 to v4.0.8 ([067e9aa](https://github.com/mike-works/web-security-fundamentals.git/commit/067e9aa))

## [1.0.39](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.38...v1.0.39) (2019-05-08)


### Bug Fixes

* **deps:** update dependency sqlite3 to v4.0.7 ([4eaee9c](https://github.com/mike-works/web-security-fundamentals.git/commit/4eaee9c))

## [1.0.38](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.37...v1.0.38) (2019-05-05)


### Bug Fixes

* **deps:** update dependency helmet to v3.18.0 ([a7f9988](https://github.com/mike-works/web-security-fundamentals.git/commit/a7f9988))

## [1.0.37](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.36...v1.0.37) (2019-05-05)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.5 ([db9d935](https://github.com/mike-works/web-security-fundamentals.git/commit/db9d935))

## [1.0.36](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.35...v1.0.36) (2019-05-03)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.4 ([db921eb](https://github.com/mike-works/web-security-fundamentals.git/commit/db921eb))

## [1.0.35](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.34...v1.0.35) (2019-05-03)


### Bug Fixes

* **deps:** update dependency helmet to v3.17.0 ([b82181b](https://github.com/mike-works/web-security-fundamentals.git/commit/b82181b))

## [1.0.34](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.33...v1.0.34) (2019-05-03)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.3 ([f0f3ff5](https://github.com/mike-works/web-security-fundamentals.git/commit/f0f3ff5))

## [1.0.33](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.32...v1.0.33) (2019-05-01)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.2 ([3fa911c](https://github.com/mike-works/web-security-fundamentals.git/commit/3fa911c))

## [1.0.32](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.31...v1.0.32) (2019-05-01)


### Bug Fixes

* **deps:** update dependency nodemon to v1.19.0 ([df95d2a](https://github.com/mike-works/web-security-fundamentals.git/commit/df95d2a))

## [1.0.31](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.30...v1.0.31) (2019-04-30)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.1 ([56b4eb5](https://github.com/mike-works/web-security-fundamentals.git/commit/56b4eb5))

## [1.0.30](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.29...v1.0.30) (2019-04-29)


### Bug Fixes

* **deps:** update dependency sequelize to v5.8.0 ([1677aa6](https://github.com/mike-works/web-security-fundamentals.git/commit/1677aa6))

## [1.0.29](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.28...v1.0.29) (2019-04-26)


### Bug Fixes

* **deps:** update dependency body-parser to v1.19.0 ([12826b1](https://github.com/mike-works/web-security-fundamentals.git/commit/12826b1))

## [1.0.28](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.27...v1.0.28) (2019-04-26)


### Bug Fixes

* **deps:** update dependency sequelize to v5.7.6 ([fc1035b](https://github.com/mike-works/web-security-fundamentals.git/commit/fc1035b))

## [1.0.27](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.26...v1.0.27) (2019-04-24)


### Bug Fixes

* **deps:** update dependency sequelize to v5.7.5 ([5160d78](https://github.com/mike-works/web-security-fundamentals.git/commit/5160d78))

## [1.0.26](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.25...v1.0.26) (2019-04-23)


### Bug Fixes

* **deps:** update dependency sequelize to v5 [security] ([b359c1f](https://github.com/mike-works/web-security-fundamentals.git/commit/b359c1f))

## [1.0.25](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.24...v1.0.25) (2019-04-23)


### Bug Fixes

* **deps:** update dependency csurf to v1.10.0 ([9879ed8](https://github.com/mike-works/web-security-fundamentals.git/commit/9879ed8))

## [1.0.24](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.23...v1.0.24) (2019-04-14)


### Bug Fixes

* **deps:** update dependency bcrypt to v3.0.6 ([32aa59d](https://github.com/mike-works/web-security-fundamentals.git/commit/32aa59d))

## [1.0.23](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.22...v1.0.23) (2019-04-11)


### Bug Fixes

* **deps:** update dependency express-session to v1.16.1 ([f73d956](https://github.com/mike-works/web-security-fundamentals.git/commit/f73d956))

## [1.0.22](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.21...v1.0.22) (2019-04-11)


### Bug Fixes

* **deps:** update dependency express-session to v1.16.0 ([0cc3495](https://github.com/mike-works/web-security-fundamentals.git/commit/0cc3495))

## [1.0.21](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.20...v1.0.21) (2019-04-08)


### Bug Fixes

* **deps:** update dependency nodemon to v1.18.11 ([6e0ec17](https://github.com/mike-works/web-security-fundamentals.git/commit/6e0ec17))

## [1.0.20](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.19...v1.0.20) (2019-04-03)


### Bug Fixes

* **deps:** update dependency commander to v2.20.0 ([c3d6de5](https://github.com/mike-works/web-security-fundamentals.git/commit/c3d6de5))

## [1.0.19](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.18...v1.0.19) (2019-03-30)


### Bug Fixes

* **deps:** update dependency sequelize to v4.43.1 ([11adc4d](https://github.com/mike-works/web-security-fundamentals.git/commit/11adc4d))

## [1.0.18](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.17...v1.0.18) (2019-03-19)


### Bug Fixes

* **deps:** update dependency bcrypt to v3.0.5 ([4f3195f](https://github.com/mike-works/web-security-fundamentals.git/commit/4f3195f))

## [1.0.17](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.16...v1.0.17) (2019-03-10)


### Bug Fixes

* **deps:** update dependency helmet to v3.16.0 ([4d832d9](https://github.com/mike-works/web-security-fundamentals.git/commit/4d832d9))

## [1.0.16](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.15...v1.0.16) (2019-03-03)


### Bug Fixes

* **deps:** update dependency sequelize to v4.43.0 ([a06aea7](https://github.com/mike-works/web-security-fundamentals.git/commit/a06aea7))

## [1.0.15](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.14...v1.0.15) (2019-02-27)


### Bug Fixes

* **deps:** update dependency sequelize to v4.42.1 ([f8cf116](https://github.com/mike-works/web-security-fundamentals.git/commit/f8cf116))

## [1.0.14](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.13...v1.0.14) (2019-02-13)


### Bug Fixes

* **deps:** update dependency cookie-parser to v1.4.4 ([070b0b7](https://github.com/mike-works/web-security-fundamentals.git/commit/070b0b7))

## [1.0.13](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.12...v1.0.13) (2019-02-10)


### Bug Fixes

* **deps:** update dependency helmet to v3.15.1 ([67faa4b](https://github.com/mike-works/web-security-fundamentals.git/commit/67faa4b))

## [1.0.12](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.11...v1.0.12) (2019-02-08)


### Bug Fixes

* **deps:** update dependency nodemon to v1.18.10 ([530c6fa](https://github.com/mike-works/web-security-fundamentals.git/commit/530c6fa))

## [1.0.11](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.10...v1.0.11) (2019-02-06)


### Bug Fixes

* **deps:** update dependency bcrypt to v3.0.4 ([08cdcc6](https://github.com/mike-works/web-security-fundamentals.git/commit/08cdcc6))

## [1.0.10](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.9...v1.0.10) (2019-01-11)


### Bug Fixes

* **deps:** update dependency sqlite3 to v4.0.6 ([df40aff](https://github.com/mike-works/web-security-fundamentals.git/commit/df40aff))

## [1.0.9](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.8...v1.0.9) (2019-01-05)


### Bug Fixes

* **deps:** update dependency chalk to v2.4.2 ([b437e16](https://github.com/mike-works/web-security-fundamentals.git/commit/b437e16))

## [1.0.8](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.7...v1.0.8) (2018-12-24)


### Bug Fixes

* **deps:** update dependency bcrypt to v3.0.3 ([a2915bc](https://github.com/mike-works/web-security-fundamentals.git/commit/a2915bc))

## [1.0.7](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.6...v1.0.7) (2018-12-22)


### Bug Fixes

* **deps:** update dependency debug to v4.1.1 ([f724ea5](https://github.com/mike-works/web-security-fundamentals.git/commit/f724ea5))

## [1.0.6](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.5...v1.0.6) (2018-12-14)


### Bug Fixes

* **deps:** update dependency nodemon to v1.18.9 ([c232bfc](https://github.com/mike-works/web-security-fundamentals.git/commit/c232bfc))

## [1.0.5](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.4...v1.0.5) (2018-12-13)


### Bug Fixes

* **deps:** update dependency sequelize to v4.42.0 ([7f89a64](https://github.com/mike-works/web-security-fundamentals.git/commit/7f89a64))

## [1.0.4](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.3...v1.0.4) (2018-12-10)


### Bug Fixes

* **deps:** update dependency nodemon to v1.18.8 ([21e0fa7](https://github.com/mike-works/web-security-fundamentals.git/commit/21e0fa7))

## [1.0.3](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.2...v1.0.3) (2018-11-27)


### Bug Fixes

* **deps:** update dependency nodemon to v1.18.7 ([77d83f1](https://github.com/mike-works/web-security-fundamentals.git/commit/77d83f1))

## [1.0.2](https://github.com/mike-works/web-security-fundamentals.git/compare/v1.0.1...v1.0.2) (2018-11-12)


### Bug Fixes

* shared renovate config ([5808fc5](https://github.com/mike-works/web-security-fundamentals.git/commit/5808fc5))
* **deps:** update dependency helmet to v3.15.0 ([336f6f8](https://github.com/mike-works/web-security-fundamentals.git/commit/336f6f8))
* **deps:** update dependency sequelize to v4.41.1 ([9a92081](https://github.com/mike-works/web-security-fundamentals.git/commit/9a92081))
* **deps:** update dependency sequelize to v4.41.2 ([008b8cc](https://github.com/mike-works/web-security-fundamentals.git/commit/008b8cc))
* **deps:** update dependency sqlite3 to v4.0.4 ([80f32cc](https://github.com/mike-works/web-security-fundamentals.git/commit/80f32cc))

## [1.0.1](https://github.com/mike-works/web-security-fundamentals/compare/v1.0.0...v1.0.1) (2018-08-19)


### Bug Fixes

* update readme ([691031f](https://github.com/mike-works/web-security-fundamentals/commit/691031f))

# 1.0.0 (2018-08-19)


### Bug Fixes

* security ([6678105](https://github.com/mike-works/web-security-fundamentals/commit/6678105))
* semantic-release ([116c26c](https://github.com/mike-works/web-security-fundamentals/commit/116c26c))
